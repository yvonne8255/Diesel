import './style.css';
import * as d3 from 'd3';

const n0 = d3.format(',.0f');
const compact = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 0 });
const fmt = (v) => (v === '' || v == null || isNaN(+v) ? '' : n0(+v));
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'];
const accent = () => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
const css = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
const $ = (s) => document.querySelector(s);

const base = import.meta.env.BASE_URL;
const load = (name) => d3.csv(`${base}data/${name}.csv`);

const data = {};
let gvSel = null;

function kpis() {
  const s = data.summary;
  $('#kpi-total').textContent = n0(+s[0].value);
  $('#kpi-fills').textContent = n0(+s[1].value);
  $('#kpi-veh').textContent = n0(+s[2].value);
}

function chart() {
  const box = $('#monthly-chart');
  box.replaceChildren();
  const rows = data.monthly.map((r) => ({ m: r.month, v: +r.liters }));
  const W = Math.max(box.clientWidth, 300), H = 220, mt = 22, mb = 26, ml = 8, mr = 8;
  const x = d3.scaleBand().domain(rows.map((r) => r.m)).range([ml, W - mr]).padding(0.28);
  const y = d3.scaleLinear().domain([0, d3.max(rows, (r) => r.v)]).nice().range([H - mb, mt]);
  const svg = d3.select(box).append('svg').attr('width', '100%').attr('viewBox', `0 0 ${W} ${H}`).attr('role', 'img').attr('aria-label', 'Diesel litres by month');
  y.ticks(4).forEach((t) => svg.append('line').attr('x1', ml).attr('x2', W - mr).attr('y1', y(t)).attr('y2', y(t)).attr('stroke', css('--grid')));
  svg.selectAll('rect').data(rows).join('rect').attr('x', (r) => x(r.m)).attr('width', x.bandwidth()).attr('y', (r) => y(r.v)).attr('height', (r) => y(0) - y(r.v)).attr('rx', 4).attr('fill', accent());
  svg.selectAll('text.v').data(rows).join('text').attr('class', 'v').attr('x', (r) => x(r.m) + x.bandwidth() / 2).attr('y', (r) => y(r.v) - 6).attr('text-anchor', 'middle').attr('font-size', 11).attr('fill', css('--muted')).text((r) => compact.format(r.v));
  svg.selectAll('text.m').data(rows).join('text').attr('class', 'm').attr('x', (r) => x(r.m) + x.bandwidth() / 2).attr('y', H - 8).attr('text-anchor', 'middle').attr('font-size', 11).attr('fill', css('--muted')).text((r) => r.m);
}

const shade = (v, max) => `color-mix(in srgb, ${accent()} ${Math.round(35 * (v / max))}%, transparent)`;

function groups() {
  const tb = $('#groups-table tbody');
  tb.replaceChildren();
  data.groups.forEach((r) => {
    const tr = document.createElement('tr');
    if (r.item_group === 'All other groups') tr.className = 'other';
    const max = d3.max(MONTHS, (m) => +r[m]) || 1;
    [r.rank || '', r.item_group, ...MONTHS.map((m) => fmt(r[m])), fmt(r.total)].forEach((t, i) => {
      const td = document.createElement('td');
      td.textContent = t;
      if (i >= 2 && i <= 10) td.style.background = shade(+r[MONTHS[i - 2]], max);
      if (i === 11) td.className = 'tot';
      tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
}

function vehicles() {
  const tb = $('#veh-table tbody');
  tb.replaceChildren();
  const rows = data.vehicles;
  const max = d3.max(rows, (r) => +r.liters) || 1;
  rows.forEach((r) => {
    const tr = document.createElement('tr');
    [r.rank, r.vehicle, r.item_group, r.tonnage || 'n/a', fmt(r.fills), fmt(r.liters)].forEach((t, i) => {
      const td = document.createElement('td');
      td.textContent = t;
      if (i === 2) td.className = 'tl';
      if (i === 5) {
        td.className = 'tot';
        const p = ((100 * +r.liters) / max).toFixed(1);
        td.style.background = `linear-gradient(to left, color-mix(in srgb, ${accent()} 38%, transparent) ${p}%, transparent ${p}%)`;
      }
      tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
}

function groupVehicles() {
  const tb = $('#gv-table tbody');
  const tabs = $('#gv-tabs');
  tb.replaceChildren();
  tabs.replaceChildren();
  const rows = data.group_vehicles;
  const groupsList = [...new Set(rows.map((r) => r.item_group))];
  if (!gvSel || !groupsList.includes(gvSel)) gvSel = groupsList[0];
  groupsList.forEach((g) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = g;
    b.setAttribute('role', 'tab');
    b.setAttribute('aria-selected', g === gvSel ? 'true' : 'false');
    b.addEventListener('click', () => { gvSel = g; groupVehicles(); });
    tabs.appendChild(b);
  });
  rows.filter((r) => r.item_group === gvSel).forEach((r) => {
    const max = d3.max(MONTHS, (m) => +r[m]) || 1;
    const tr = document.createElement('tr');
    [r.rank, r.vehicle, ...MONTHS.map((m) => fmt(r[m])), fmt(r.total), fmt(r.fills)].forEach((t, i) => {
      const td = document.createElement('td');
      td.textContent = t;
      if (i >= 2 && i <= 10) td.style.background = shade(+r[MONTHS[i - 2]], max);
      if (i === 11) td.className = 'tot';
      tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
}

async function init() {
  const names = ['summary', 'monthly', 'groups', 'vehicles', 'group_vehicles'];
  const loaded = await Promise.all(names.map(load));
  names.forEach((n, i) => (data[n] = loaded[i]));
  kpis(); chart(); groups(); vehicles(); groupVehicles();
  let t;
  window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(chart, 120); });
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { chart(); groups(); vehicles(); groupVehicles(); });
}
init().catch((e) => { document.querySelector('.dd').insertAdjacentHTML('afterbegin', `<p class="foot">Could not load data files: ${e.message}</p>`); });
